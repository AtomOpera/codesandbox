import "./styles.css";
import { useState, useEffect } from "react";
import { arrayOfOrgs } from "./arrayOfOrgs";

export default function App() {
  const createOrganization = (name) => {
    console.log(name);
    return name;
  };
  const [result, setResult] = useState([]);
  let totalOperations = [];
  const total = arrayOfOrgs.length;
  console.log("total", total);
  const createOrganizations = async () => {
    // Organizations to create at a time;
    const concurrent = 50;
    for (let i = 0; i < total; i += concurrent) {
      const operations = [];
      for (let j = 0; j < concurrent; j += 1) {
        const name = arrayOfOrgs[i + j];
        operations[i + j] = createOrganization(`${i + j + 1} - ${name}`);
      }
      await Promise.all(operations);
      totalOperations = [...totalOperations, ...operations];
    }
    // setResult(operations);
  };

  useEffect(() => {
    (async () => {
      await createOrganizations();
      setResult(totalOperations);
    })();
  }, []);
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Concurrent</h2>
      <pre>{JSON.stringify(result)}</pre>
      {/* <pre>{JSON.stringify(operations)}</pre> */}
    </div>
  );
}
